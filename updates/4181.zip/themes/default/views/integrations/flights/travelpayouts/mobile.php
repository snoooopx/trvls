<style>
.navbar {display:none !important}
.mob-bg {display:none}
.footerbg {display:none}
.foot-nav {display:none}
 footer {display:none}
 body {background-color:white}
</style>
<script charset="utf-8" src="<?php echo $WidgetURLMobile; ?>" async></script>
