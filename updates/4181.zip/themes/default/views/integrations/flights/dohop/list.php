<style>
html, body {
height: 100%;
overflow: hidden;
}
#wrapper {
width: 100%;
position:static;
background-color: transparent;
margin-top: -20px;
}
footer { display:none; }
.mob-bg { display:none; }
.newsletter { display:none; }
</style>

<div id="wrapper">
<iframe  src="//whitelabel.dohop.com/w/<?php echo $username;?>" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="600" scrolling="auto"></iframe>
</div>