<style>
html {
    overflow-y: scroll;
}
footer {
    display : none;
}
iframe {
width: 100%;
position:fixed;
background-color: transparent;
padding: 0px;
border: 0px;
background: #fafafa;
min-height: 100%;
margin-top:-60px;
margin-bottom:1800px;
overflow-y: hidden;
}
.mob-bg {
    display:none;
}
.newsletter {
    display:none;
}

</style>
<iframe src="//brands.datahc.com/?a_aid=<?php echo $aid; ?>&brandid=<?php echo $brandID; ?>&languageCode=EN" frameborder="0" height="100%" width="100%"></iframe>
