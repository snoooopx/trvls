<?php
//error_reporting(0);
include('header.php');
//include('functions.php');

echo $this->content();

include('footer.php');
