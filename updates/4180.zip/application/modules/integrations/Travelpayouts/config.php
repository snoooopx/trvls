<?php

/*
Module Icon: <i class="fa fa-plane"></i>
Module Name: travelpayouts
Module Display Name: Travelpayouts Flights
Admin Menu: <li><a href="%baseurl%admin/travelpayouts/settings/"><span class="fa fa-plane"></span> Travelpayouts</a></li>
Integration: Yes
Version: 1.0
*/