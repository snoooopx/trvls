<?php

/*
Module Icon: <i class="fa fa-building"></i>
Module Name: EAN
Module Display Name: Expedia Hotels
Admin Menu: <li><a href="%baseurl%admin/ean/settings/"><span class="fa fa-building"></span> Hotels Expedia</a></li>
Integration: Yes
Version: 1.0
*/